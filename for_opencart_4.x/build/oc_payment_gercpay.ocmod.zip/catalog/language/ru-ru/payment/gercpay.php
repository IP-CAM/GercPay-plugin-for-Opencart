<?php
// Heading
$_['heading_title'] = 'GercPay';

// Text
$_['text_title'] = '<span style="background: url(/image/payment/gercpay.svg) 0 0/auto 100% no-repeat !important;"><img src="/image/payment/gercpay.png" alt="GercPay" title="GercPay"></span>&nbsp;Оплата Visa, Mastercard, GooglePay, ApplePay';
$_['text_payment_by_card'] = 'Оплата картой на сайте';
?>