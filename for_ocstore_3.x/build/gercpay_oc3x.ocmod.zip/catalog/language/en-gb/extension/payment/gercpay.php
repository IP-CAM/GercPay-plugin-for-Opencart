<?php
// Text
$_['text_title'] = '<span style="background: url(image/payment/gercpay.svg) 0 0 no-repeat !important;"><img src="image/payment/gercpay.png" alt="GercPay" title="GercPay"></span>&nbsp;Payment Visa, Mastercard, GooglePay, ApplePay';
$_['text_payment_by_card'] = 'Payment by card on the site';
?>